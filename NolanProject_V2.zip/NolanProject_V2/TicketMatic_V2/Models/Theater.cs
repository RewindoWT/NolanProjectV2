﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketMatic_V2.Models
{
    public class Theater
    {
        public int id { get; set; }
        public int theaterCapacity { get; set; }
    }
}
